import './App.css';
import Home from './Components/Home'
import Contador from './Components/Contador'

function App() {
  return (
   <div className="App">
    Order Online<br />
    <Contador />
    <Home />
   </div>
  );
}

export default App;
