import React from 'react'; 
import Productos from './Productos';


function Home(){
  return(
    <>
  
      <div>
        <Productos />
      </div>
    </>
  )
}

export default Home; 
